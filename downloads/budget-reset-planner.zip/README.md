# 30-Day Budget Reset Planner

Included files:
- printable HTML resource
- guide/source markdown
- Pinterest-safe draft copy

No secrets. No affiliate shorteners. Built for US/UK/CA/AU/EU readers.
