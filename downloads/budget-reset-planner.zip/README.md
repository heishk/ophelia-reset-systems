# 30-Day Budget Reset Planner

Included files:
- printable HTML resource
- guide/source markdown
- Pinterest draft copy

Printable resource.
