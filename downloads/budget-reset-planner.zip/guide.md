# The 30-Day Budget Reset Planner

Audience: Tier 1 households who want a clean financial reset without complex spreadsheets.

## The problem
Money can get messy in quiet ways. A few forgotten subscriptions, one vague savings goal, and several small impulse purchases can make the month feel tighter than it should. Most people do not need a complicated finance system first. They need one calm reset that shows where the money is going and what to change this week.

## The promise
This planner gives you a simple 30-day reset that tracks spending, cancels leaks, and sets a realistic savings plan. It is built for normal households: renters, couples, solo earners, parents, students, and anyone who wants a clearer month without building a giant spreadsheet.

## How to use it
Start with one page and one week. Do not try to fix every account in one sitting. The goal is to make money visible, choose one useful cut, and set a weekly cap you can actually follow.

## Reset plan
- Day 1: list every recurring bill and subscription
- Day 2: sort expenses into needs, wants, leaks, and goals
- Day 3: choose one cancellation or downgrade
- Day 4: set a weekly spending cap
- Day 5: create a no-spend reset list
- Day 6: define one emergency-fund target
- Day 7: review and repeat for four weeks

## What counts as a leak
A leak is not always a bad purchase. It is any charge you would not choose again today. That can be an app trial, a delivery habit, a duplicate streaming service, a storage plan, or a premium tier you barely use. The planner asks you to find one leak at a time because small wins are easier to keep.

## Keep the reset realistic
Do not cut essentials to make the page look good. Keep rent, utilities, groceries, transport, childcare, medication, and debt minimums visible. The reset is about clarity and better choices, not shame.

## Good first target
Pick one weekly number for flexible spending. If the number is too strict, raise it. A useful budget is one you can repeat for four weeks.
