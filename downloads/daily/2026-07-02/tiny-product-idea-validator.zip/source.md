# Tiny Product Idea Validator

A one-page worksheet for deciding if a digital product idea is worth making today.

Price position: Free.
Audience: new creators, Etsy sellers, Gumroad makers, and solo operators in US, UK, CA, AU, and EU markets.

## What this is
Use this before building another random printable. It forces a quick buyer, pain, proof, and first-channel check so weak ideas die before they cost a day.

## How to use it
Print the PDF or open the HTML file. Fill one section at a time. Keep the first pass rough. The value comes from making a decision, not making the worksheet pretty.

## Buyer
- Who would search for this?
- What would they type into Etsy, Google, Pinterest, or Gumroad?
- Would they use it this week?

## Pain
- What annoying task does this make easier?
- What does the buyer already try before buying?
- What would make them save or share it?

## Proof
- Name three similar products or search results.
- Write one thing those products do badly.
- Write one small upgrade this product can own.

## Ship test
- Make a plain PDF first.
- Post the free version on the JERICCO hub.
- Track clicks, saves, email signups, and comments before expanding it.

## Worksheet
Use the lines below for the first pass.

- Idea: ______________________________
- Target buyer: ______________________________
- Search phrase: ______________________________
- Problem: ______________________________
- Small upgrade: ______________________________
- Free version: ______________________________
- Paid version: ______________________________
- First traffic channel: ______________________________

## Support note
This is a digital download. No physical item is shipped. If a file does not open, try the PDF first, then the HTML version in a browser.

## Safety note
This product gives organization prompts only. It does not provide legal, tax, medical, or investment advice.
