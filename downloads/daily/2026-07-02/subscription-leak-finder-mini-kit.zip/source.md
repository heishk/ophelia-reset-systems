# Subscription Leak Finder Mini Kit

A printable mini kit for finding recurring charges, downgrades, and forgotten subscriptions.

Price position: $5.
Audience: households, renters, students, couples, and solo earners in Tier 1 markets who want a simple money reset.

## What this is
This is not a finance course. It is a fast audit kit for listing every recurring payment, choosing what to cancel or downgrade, and giving next month more breathing room.

## How to use it
Print the PDF or open the HTML file. Fill one section at a time. Keep the first pass rough. The value comes from making a decision, not making the worksheet pretty.

## Subscription sweep
- Check bank statements for the last 60 days.
- Write every recurring charge, even the small ones.
- Mark each charge as keep, cancel, downgrade, or review later.

## Value check
- Ask if you used it in the last 30 days.
- Ask if a free version would do enough.
- Ask if the plan can be shared, paused, or reduced.

## Cancel script
- Use the included short script when a service pushes back.
- Record confirmation numbers or emails.
- Set a reminder to verify the charge is gone next cycle.

## Next-month rule
- Move the saved amount into debt, emergency cash, or a specific bill.
- Do not let the savings disappear into random spending.

## Worksheet
Use the lines below for the first pass.

- Service: ______________________________
- Monthly cost: ______________________________
- Last used: ______________________________
- Keep/cancel/downgrade: ______________________________
- Action date: ______________________________
- Confirmation: ______________________________
- Next charge date: ______________________________
- Savings target: ______________________________

## Support note
This is a digital download. No physical item is shipped. If a file does not open, try the PDF first, then the HTML version in a browser.

## Safety note
This product gives organization prompts only. It does not provide legal, tax, medical, or investment advice.
