# 7-Day Reset Home System

Included files:
- printable HTML resource
- guide/source markdown
- Pinterest draft copy

Printable resource.
